import { handleRequest } from '../../index.ts';

if (typeof Deno !== 'undefined' && typeof Deno.serve === 'function') {
  Deno.serve(handleRequest);
}

export default {
  fetch: handleRequest,
};
