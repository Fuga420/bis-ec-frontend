/**
 * gas-ai-batch-relay (Readdy Functions / Edge Functions 互換)
 * 
 * Readdy（BIS管理画面）と Google Apps Script（GAS）間の「一括AI出品ドラフト生成」専用中継エッジ関数。
 * 
 * - ランタイム: Deno / Web Standard API (Request, Response, fetch)
 * - バッチ3アクション限定:
 *     1. create_ai_product_draft_batch (POST)
 *     2. get_ai_product_draft_batch (GET / POST -> GAS GET)
 *     3. retry_ai_product_draft_batch (POST)
 * - 既存Secrets (GAS_WEBHOOK_URL, GAS_ADMIN_SECRET) より接続先・管理キーを取得してサーバー側注入
 * - クライアントからの管理キー改ざん防止・CORS制御・30秒タイムアウト・エラーハンドリング
 */

const DEFAULT_TIMEOUT_MS = 30000;

// CORSヘッダー定義
const corsHeaders: Record<string, string> = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With',
  'Access-Control-Max-Age': '86400',
};

/**
 * 環境変数の安全な取得 (Deno / Node.js 双方に対応)
 */
function getEnvVar(key: string): string {
  if (typeof Deno !== 'undefined' && typeof Deno.env?.get === 'function') {
    return Deno.env.get(key) || '';
  }
  if (typeof process !== 'undefined' && process.env) {
    return process.env[key] || '';
  }
  return '';
}

/**
 * JSON レスポンス生成ヘルパー
 */
function jsonResponse(data: unknown, status = 200, extraHeaders: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      ...corsHeaders,
      'Content-Type': 'application/json',
      ...extraHeaders,
    },
  });
}

/**
 * メインリクエストハンドラー (Web Standard Request -> Response)
 */
export async function handleRequest(req: Request): Promise<Response> {
  // 1. CORS Preflight (OPTIONS) 即時応答
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: corsHeaders,
    });
  }

  // 2. HTTPメソッド制限 (GET, POST のみ)
  if (req.method !== 'GET' && req.method !== 'POST') {
    return jsonResponse(
      {
        success: false,
        error_code: 'METHOD_NOT_ALLOWED',
        message: `HTTP Method ${req.method} is not allowed`,
      },
      405,
      { Allow: 'GET, POST, OPTIONS' }
    );
  }

  // 3. 環境設定の取得と検証 (既存Secretsより)
  const gasWebhookUrl = getEnvVar('GAS_WEBHOOK_URL').trim();
  const gasAdminSecret = getEnvVar('GAS_ADMIN_SECRET').trim();

  if (!gasWebhookUrl || !gasAdminSecret) {
    console.error('[BatchRelay] Missing required environment variables (GAS_WEBHOOK_URL or GAS_ADMIN_SECRET)');
    return jsonResponse(
      {
        success: false,
        error_code: 'SERVER_CONFIGURATION_ERROR',
        message: 'Server configuration error: missing GAS credentials in Secrets',
      },
      500
    );
  }

  // 4. リクエストパラメータ・アクションの解析
  const url = new URL(req.url);
  let body: Record<string, any> = {};

  if (req.method === 'POST') {
    try {
      const text = await req.text();
      if (text && text.trim()) {
        body = JSON.parse(text);
      }
    } catch (_) {
      body = {};
    }
  }

  let action = String(body.action || url.searchParams.get('action') || '').trim();
  if (!action && req.method === 'GET' && url.searchParams.get('batch_id')) {
    action = 'get_ai_product_draft_batch';
  }

  const ALLOWED_ACTIONS = [
    'create_ai_product_draft_batch',
    'get_ai_product_draft_batch',
    'retry_ai_product_draft_batch',
  ];

  if (!ALLOWED_ACTIONS.includes(action)) {
    return jsonResponse(
      {
        success: false,
        error_code: 'ACTION_NOT_SUPPORTED',
        message: `Action '${action}' is not supported. Allowed actions: ${ALLOWED_ACTIONS.join(', ')}`,
      },
      400
    );
  }

  // 5. アクション別バリデーションおよび上流GAS転送リクエスト構築
  let upstreamUrl = gasWebhookUrl;
  let upstreamMethod = 'POST';
  let upstreamBody: Record<string, any> | null = null;

  if (action === 'create_ai_product_draft_batch') {
    if (req.method !== 'POST') {
      return jsonResponse(
        {
          success: false,
          error_code: 'METHOD_NOT_ALLOWED',
          message: 'create_ai_product_draft_batch requires POST method',
        },
        405,
        { Allow: 'POST' }
      );
    }

    const requestId = String(body.request_id || '').trim();
    if (!requestId) {
      return jsonResponse(
        {
          success: false,
          error_code: 'REQUEST_ID_REQUIRED',
          message: 'request_id is required for batch creation',
        },
        400
      );
    }

    if (!Array.isArray(body.product_ids) || body.product_ids.length === 0) {
      return jsonResponse(
        {
          success: false,
          error_code: 'EMPTY_PRODUCT_IDS',
          message: 'product_ids must be a non-empty array',
        },
        400
      );
    }

    if (body.product_ids.length > 20) {
      return jsonResponse(
        {
          success: false,
          error_code: 'MAX_BATCH_SIZE_EXCEEDED',
          message: 'product_ids cannot exceed 20 items',
        },
        400
      );
    }

    // サーバー側Secretsより mode: "admin", admin_key を安全に付与
    upstreamBody = {
      action: 'create_ai_product_draft_batch',
      mode: 'admin',
      admin_key: gasAdminSecret,
      request_id: requestId,
      product_ids: body.product_ids.map((id: unknown) => String(id).trim()).filter(Boolean),
      force_regenerate: Boolean(body.force_regenerate),
    };

    if (body.model_name && typeof body.model_name === 'string') {
      upstreamBody.model_name = body.model_name.trim();
    }
  } else if (action === 'get_ai_product_draft_batch') {
    const batchId = String(url.searchParams.get('batch_id') || body.batch_id || '').trim();
    if (!batchId) {
      return jsonResponse(
        {
          success: false,
          error_code: 'BATCH_ID_REQUIRED',
          message: 'batch_id is required',
        },
        400
      );
    }

    // 契約書に合わせ、GASへGET転送
    const separator = upstreamUrl.includes('?') ? '&' : '?';
    const qParams = new URLSearchParams({
      mode: 'admin',
      admin_key: gasAdminSecret,
      action: 'get_ai_product_draft_batch',
      batch_id: batchId,
    });

    upstreamUrl = `${upstreamUrl}${separator}${qParams.toString()}`;
    upstreamMethod = 'GET';
    upstreamBody = null;
  } else if (action === 'retry_ai_product_draft_batch') {
    if (req.method !== 'POST') {
      return jsonResponse(
        {
          success: false,
          error_code: 'METHOD_NOT_ALLOWED',
          message: 'retry_ai_product_draft_batch requires POST method',
        },
        405,
        { Allow: 'POST' }
      );
    }

    const batchId = String(body.batch_id || url.searchParams.get('batch_id') || '').trim();
    if (!batchId) {
      return jsonResponse(
        {
          success: false,
          error_code: 'BATCH_ID_REQUIRED',
          message: 'batch_id is required',
        },
        400
      );
    }

    const requestId = String(body.request_id || '').trim();
    if (!requestId) {
      return jsonResponse(
        {
          success: false,
          error_code: 'REQUEST_ID_REQUIRED',
          message: 'request_id is required for retry',
        },
        400
      );
    }

    upstreamBody = {
      action: 'retry_ai_product_draft_batch',
      mode: 'admin',
      admin_key: gasAdminSecret,
      batch_id: batchId,
      request_id: requestId,
    };
  }

  // 6. 上流 GAS へのリレー実行 (タイムアウト制御・リダイレクト追従)
  const timeoutMsStr = getEnvVar('GAS_REQUEST_TIMEOUT_MS');
  const timeoutMs = parseInt(timeoutMsStr, 10) || DEFAULT_TIMEOUT_MS;

  try {
    const fetchOptions: RequestInit = {
      method: upstreamMethod,
      headers: {
        Accept: 'application/json',
      },
      redirect: 'follow', // GAS Web App 302 リダイレクト追従に必須
      signal: AbortSignal.timeout(timeoutMs),
    };

    if (upstreamBody) {
      fetchOptions.headers = {
        ...fetchOptions.headers,
        'Content-Type': 'application/json',
      };
      fetchOptions.body = JSON.stringify(upstreamBody);
    }

    const gasResponse = await fetch(upstreamUrl, fetchOptions);
    const responseText = await gasResponse.text();

    let jsonOutput: unknown;
    try {
      jsonOutput = JSON.parse(responseText);
    } catch (_) {
      console.error('[BatchRelay] Upstream GAS returned non-JSON:', responseText.substring(0, 300));
      return jsonResponse(
        {
          success: false,
          error_code: 'GAS_INVALID_RESPONSE',
          message: 'Upstream GAS returned an invalid response format',
        },
        502
      );
    }

    const statusCode = gasResponse.status >= 200 && gasResponse.status < 300 ? 200 : gasResponse.status;
    return jsonResponse(jsonOutput, statusCode);
  } catch (err: unknown) {
    const error = err as Error;
    if (error.name === 'TimeoutError' || error.name === 'AbortError') {
      console.error('[BatchRelay] Upstream GAS timeout after', timeoutMs, 'ms');
      return jsonResponse(
        {
          success: false,
          error_code: 'GAS_TIMEOUT',
          message: `Upstream GAS timed out after ${timeoutMs}ms`,
        },
        504
      );
    }

    console.error('[BatchRelay] Upstream connection failure:', error.message);
    return jsonResponse(
      {
        success: false,
        error_code: 'GAS_UPSTREAM_ERROR',
        message: 'Failed to communicate with GAS upstream',
      },
      502
    );
  }
}

// Deno / Readdy Functions / Supabase Edge Functions のエントリポイント
if (typeof Deno !== 'undefined' && typeof Deno.serve === 'function') {
  Deno.serve(handleRequest);
}

// デフォルトエクスポート (Cloudflare Workers / Vercel Edge 互換)
export default {
  fetch: handleRequest,
};
