const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const {
  createBatchRelayHandler,
  validateConfig,
  verifyJwt,
  handleCors
} = require('../index.js');

const mockEnv = {
  GAS_WEBHOOK_URL: 'https://script.google.com/macros/s/AKfyc_test/exec',
  GAS_ADMIN_SECRET: 'test-admin-secret-key-12345',
  ALLOWED_ORIGINS: 'https://readdy.ai,https://app.currykicks.com',
  JWT_SECRET: 'test-jwt-secret-xyz',
  JWT_REQUIRED: 'false',
  GAS_REQUEST_TIMEOUT_MS: '5000'
};

function createMockReq({
  method = 'POST',
  headers = {},
  query = {},
  body = {}
} = {}) {
  return {
    method,
    headers: { ...headers },
    query: { ...query },
    body: { ...body }
  };
}

function createMockRes() {
  return {
    statusCode: 200,
    headers: {},
    body: null,
    status(code) {
      this.statusCode = code;
      return this;
    },
    setHeader(key, val) {
      this.headers[key.toLowerCase()] = val;
      return this;
    },
    json(data) {
      this.body = data;
      return this;
    },
    end() {
      return this;
    }
  };
}

function signJwt(payload, secret, expiresInSec = 3600) {
  const header = { alg: 'HS256', typ: 'JWT' };
  const expPayload = {
    ...payload,
    exp: Math.floor(Date.now() / 1000) + expiresInSec
  };
  const headerB64 = Buffer.from(JSON.stringify(header)).toString('base64url');
  const payloadB64 = Buffer.from(JSON.stringify(expPayload)).toString('base64url');
  const sig = crypto
    .createHmac('sha256', secret)
    .update(`${headerB64}.${payloadB64}`)
    .digest('base64url');
  return `${headerB64}.${payloadB64}.${sig}`;
}

describe('gas-ai-batch-relay Test Suite', () => {
  describe('1. Configuration Validation', () => {
    it('1-1. Valid configuration returns normalized object', () => {
      const config = validateConfig(mockEnv);
      assert.equal(config.gasWebhookUrl, 'https://script.google.com/macros/s/AKfyc_test/exec');
      assert.equal(config.gasAdminSecret, 'test-admin-secret-key-12345');
      assert.deepEqual(config.allowedOrigins, ['https://readdy.ai', 'https://app.currykicks.com']);
      assert.equal(config.jwtSecret, 'test-jwt-secret-xyz');
      assert.equal(config.jwtRequired, false);
      assert.equal(config.timeoutMs, 5000);
    });

    it('1-2. Missing GAS_WEBHOOK_URL throws error', () => {
      assert.throws(
        () => validateConfig({ ...mockEnv, GAS_WEBHOOK_URL: '' }),
        /Missing required environment variables: GAS_WEBHOOK_URL/
      );
    });

    it('1-3. Missing GAS_ADMIN_SECRET throws error', () => {
      assert.throws(
        () => validateConfig({ ...mockEnv, GAS_ADMIN_SECRET: '' }),
        /Missing required environment variables: GAS_ADMIN_SECRET/
      );
    });

    it('1-4. Invalid URL format throws error', () => {
      assert.throws(
        () => validateConfig({ ...mockEnv, GAS_WEBHOOK_URL: 'ftp://invalid-url' }),
        /GAS_WEBHOOK_URL must be a valid HTTP\/HTTPS URL/
      );
    });

    it('1-5. Wildcard origin correctly parsed', () => {
      const config = validateConfig({ ...mockEnv, ALLOWED_ORIGINS: '*' });
      assert.deepEqual(config.allowedOrigins, ['*']);
    });
  });

  describe('2. JWT Verification', () => {
    it('2-1. Valid HS256 token returns valid=true', () => {
      const token = signJwt({ sub: 'user_123' }, 'my-secret');
      const res = verifyJwt(token, 'my-secret');
      assert.equal(res.valid, true);
      assert.equal(res.payload.sub, 'user_123');
    });

    it('2-2. Expired token returns valid=false with Token expired', () => {
      const token = signJwt({ sub: 'user_123' }, 'my-secret', -10);
      const res = verifyJwt(token, 'my-secret');
      assert.equal(res.valid, false);
      assert.equal(res.error, 'Token expired');
    });

    it('2-3. Tampered signature returns valid=false', () => {
      const token = signJwt({ sub: 'user_123' }, 'my-secret');
      const tampered = token.slice(0, -5) + 'xxxxx';
      const res = verifyJwt(tampered, 'my-secret');
      assert.equal(res.valid, false);
      assert.equal(res.error, 'Invalid signature');
    });

    it('2-4. Malformed token returns valid=false', () => {
      const res = verifyJwt('invalid.token', 'my-secret');
      assert.equal(res.valid, false);
    });
  });

  describe('3. CORS & Preflight (OPTIONS)', () => {
    it('3-1. OPTIONS preflight returns 204 with CORS headers', async () => {
      const handler = createBatchRelayHandler({ getEnv: () => mockEnv });
      const req = createMockReq({
        method: 'OPTIONS',
        headers: { origin: 'https://readdy.ai' }
      });
      const res = createMockRes();

      await handler(req, res);
      assert.equal(res.statusCode, 204);
      assert.equal(res.headers['access-control-allow-origin'], 'https://readdy.ai');
      assert.equal(res.headers['access-control-allow-methods'], 'GET, POST, OPTIONS');
    });

    it('3-2. Disallowed origin returns 403 ORIGIN_NOT_ALLOWED', async () => {
      const handler = createBatchRelayHandler({ getEnv: () => mockEnv });
      const req = createMockReq({
        method: 'POST',
        headers: { origin: 'https://malicious-site.com' },
        body: { action: 'create_ai_product_draft_batch' }
      });
      const res = createMockRes();

      await handler(req, res);
      assert.equal(res.statusCode, 403);
      assert.equal(res.body.error_code, 'ORIGIN_NOT_ALLOWED');
    });

    it('3-3. Wildcard origin accepts any origin', async () => {
      const handler = createBatchRelayHandler({
        getEnv: () => ({ ...mockEnv, ALLOWED_ORIGINS: '*' }),
        fetchFn: async () => ({
          status: 200,
          text: async () => JSON.stringify({ success: true, batch_id: 'BAT_01' })
        })
      });
      const req = createMockReq({
        method: 'POST',
        headers: { origin: 'https://any-app.com' },
        body: {
          action: 'create_ai_product_draft_batch',
          request_id: 'REQ_01',
          product_ids: ['TMP-01']
        }
      });
      const res = createMockRes();

      await handler(req, res);
      assert.equal(res.statusCode, 200);
      assert.equal(res.headers['access-control-allow-origin'], 'https://any-app.com');
    });
  });

  describe('4. JWT Authentication Middleware', () => {
    it('4-1. Rejects request when JWT_REQUIRED=true and no token is provided', async () => {
      const handler = createBatchRelayHandler({
        getEnv: () => ({ ...mockEnv, JWT_REQUIRED: 'true' })
      });
      const req = createMockReq({
        method: 'POST',
        body: { action: 'create_ai_product_draft_batch' }
      });
      const res = createMockRes();

      await handler(req, res);
      assert.equal(res.statusCode, 401);
      assert.equal(res.body.error_code, 'UNAUTHORIZED');
    });

    it('4-2. Rejects request when invalid Bearer token is provided', async () => {
      const handler = createBatchRelayHandler({ getEnv: () => mockEnv });
      const req = createMockReq({
        method: 'POST',
        headers: { authorization: 'Bearer invalid.jwt.token' },
        body: { action: 'create_ai_product_draft_batch' }
      });
      const res = createMockRes();

      await handler(req, res);
      assert.equal(res.statusCode, 401);
      assert.equal(res.body.error_code, 'INVALID_TOKEN');
    });

    it('4-3. Accepts request when valid Bearer token is provided', async () => {
      const validToken = signJwt({ sub: 'admin' }, mockEnv.JWT_SECRET);
      let capturedPayload = null;

      const handler = createBatchRelayHandler({
        getEnv: () => mockEnv,
        fetchFn: async (url, opts) => {
          capturedPayload = JSON.parse(opts.body);
          return {
            status: 200,
            text: async () => JSON.stringify({ success: true, batch_id: 'BAT_01' })
          };
        }
      });

      const req = createMockReq({
        method: 'POST',
        headers: {
          authorization: `Bearer ${validToken}`,
          origin: 'https://readdy.ai'
        },
        body: {
          action: 'create_ai_product_draft_batch',
          request_id: 'REQ_01',
          product_ids: ['TMP-01']
        }
      });
      const res = createMockRes();

      await handler(req, res);
      assert.equal(res.statusCode, 200);
      assert.equal(res.body.success, true);
      assert.equal(capturedPayload.request_id, 'REQ_01');
    });
  });

  describe('5. Action: create_ai_product_draft_batch', () => {
    it('5-1. Rejects when request_id is missing', async () => {
      const handler = createBatchRelayHandler({ getEnv: () => mockEnv });
      const req = createMockReq({
        method: 'POST',
        body: { action: 'create_ai_product_draft_batch', product_ids: ['TMP-01'] }
      });
      const res = createMockRes();

      await handler(req, res);
      assert.equal(res.statusCode, 400);
      assert.equal(res.body.error_code, 'REQUEST_ID_REQUIRED');
    });

    it('5-2. Rejects when product_ids is empty', async () => {
      const handler = createBatchRelayHandler({ getEnv: () => mockEnv });
      const req = createMockReq({
        method: 'POST',
        body: { action: 'create_ai_product_draft_batch', request_id: 'REQ_01', product_ids: [] }
      });
      const res = createMockRes();

      await handler(req, res);
      assert.equal(res.statusCode, 400);
      assert.equal(res.body.error_code, 'EMPTY_PRODUCT_IDS');
    });

    it('5-3. Rejects when product_ids exceeds 20 items', async () => {
      const handler = createBatchRelayHandler({ getEnv: () => mockEnv });
      const over20 = Array.from({ length: 21 }, (_, i) => `TMP-${i}`);
      const req = createMockReq({
        method: 'POST',
        body: { action: 'create_ai_product_draft_batch', request_id: 'REQ_01', product_ids: over20 }
      });
      const res = createMockRes();

      await handler(req, res);
      assert.equal(res.statusCode, 400);
      assert.equal(res.body.error_code, 'MAX_BATCH_SIZE_EXCEEDED');
    });

    it('5-4. Injects mode=admin and admin_key, overrides client tampering, and forwards to GAS', async () => {
      let forwardedUrl = null;
      let forwardedOpts = null;

      const handler = createBatchRelayHandler({
        getEnv: () => mockEnv,
        fetchFn: async (url, opts) => {
          forwardedUrl = url;
          forwardedOpts = opts;
          return {
            status: 200,
            text: async () => JSON.stringify({
              success: true,
              batch_id: 'BAT_20261005_123',
              request_id: 'REQ_TAMPER_01',
              status: 'queued',
              total_count: 2
            })
          };
        }
      });

      const req = createMockReq({
        method: 'POST',
        body: {
          action: 'create_ai_product_draft_batch',
          mode: 'hacker_mode', // クライアントが改ざんを試みても
          admin_key: 'hacker_key', // サーバー側で上書き
          request_id: 'REQ_TAMPER_01',
          product_ids: ['TMP-01', 'TMP-02'],
          model_name: 'gemini-3.5-flash-lite'
        }
      });
      const res = createMockRes();

      await handler(req, res);
      assert.equal(res.statusCode, 200);
      assert.equal(forwardedUrl, mockEnv.GAS_WEBHOOK_URL);
      assert.equal(forwardedOpts.method, 'POST');

      const body = JSON.parse(forwardedOpts.body);
      assert.equal(body.mode, 'admin');
      assert.equal(body.admin_key, mockEnv.GAS_ADMIN_SECRET); // 正しいサーバーシークレットが注入された
      assert.equal(body.request_id, 'REQ_TAMPER_01');
      assert.deepEqual(body.product_ids, ['TMP-01', 'TMP-02']);
      assert.equal(body.model_name, 'gemini-3.5-flash-lite');
    });
  });

  describe('6. Action: get_ai_product_draft_batch', () => {
    it('6-1. Rejects when batch_id is missing', async () => {
      const handler = createBatchRelayHandler({ getEnv: () => mockEnv });
      const req = createMockReq({
        method: 'GET',
        query: { action: 'get_ai_product_draft_batch' }
      });
      const res = createMockRes();

      await handler(req, res);
      assert.equal(res.statusCode, 400);
      assert.equal(res.body.error_code, 'BATCH_ID_REQUIRED');
    });

    it('6-2. Forwards GET request with admin_key in query to GAS', async () => {
      let forwardedUrl = null;
      let forwardedOpts = null;

      const handler = createBatchRelayHandler({
        getEnv: () => mockEnv,
        fetchFn: async (url, opts) => {
          forwardedUrl = url;
          forwardedOpts = opts;
          return {
            status: 200,
            text: async () => JSON.stringify({
              success: true,
              batch_id: 'BAT_TEST_01',
              status: 'processing',
              items: []
            })
          };
        }
      });

      const req = createMockReq({
        method: 'GET',
        query: {
          action: 'get_ai_product_draft_batch',
          batch_id: 'BAT_TEST_01'
        }
      });
      const res = createMockRes();

      await handler(req, res);
      assert.equal(res.statusCode, 200);
      assert.equal(forwardedOpts.method, 'GET');

      const parsedUrl = new URL(forwardedUrl);
      assert.equal(parsedUrl.searchParams.get('mode'), 'admin');
      assert.equal(parsedUrl.searchParams.get('admin_key'), mockEnv.GAS_ADMIN_SECRET);
      assert.equal(parsedUrl.searchParams.get('action'), 'get_ai_product_draft_batch');
      assert.equal(parsedUrl.searchParams.get('batch_id'), 'BAT_TEST_01');
    });
  });

  describe('7. Action: retry_ai_product_draft_batch', () => {
    it('7-1. Rejects when batch_id or request_id is missing', async () => {
      const handler = createBatchRelayHandler({ getEnv: () => mockEnv });
      const req1 = createMockReq({
        method: 'POST',
        body: { action: 'retry_ai_product_draft_batch', request_id: 'REQ_01' }
      });
      const res1 = createMockRes();
      await handler(req1, res1);
      assert.equal(res1.statusCode, 400);
      assert.equal(res1.body.error_code, 'BATCH_ID_REQUIRED');

      const req2 = createMockReq({
        method: 'POST',
        body: { action: 'retry_ai_product_draft_batch', batch_id: 'BAT_01' }
      });
      const res2 = createMockRes();
      await handler(req2, res2);
      assert.equal(res2.statusCode, 400);
      assert.equal(res2.body.error_code, 'REQUEST_ID_REQUIRED');
    });

    it('7-2. Forwards retry POST request with server admin_key to GAS', async () => {
      let forwardedOpts = null;

      const handler = createBatchRelayHandler({
        getEnv: () => mockEnv,
        fetchFn: async (url, opts) => {
          forwardedOpts = opts;
          return {
            status: 200,
            text: async () => JSON.stringify({
              success: true,
              batch_id: 'BAT_01',
              status: 'queued',
              retried_count: 1
            })
          };
        }
      });

      const req = createMockReq({
        method: 'POST',
        body: {
          action: 'retry_ai_product_draft_batch',
          batch_id: 'BAT_01',
          request_id: 'REQ_RETRY_01'
        }
      });
      const res = createMockRes();

      await handler(req, res);
      assert.equal(res.statusCode, 200);

      const body = JSON.parse(forwardedOpts.body);
      assert.equal(body.mode, 'admin');
      assert.equal(body.admin_key, mockEnv.GAS_ADMIN_SECRET);
      assert.equal(body.batch_id, 'BAT_01');
      assert.equal(body.request_id, 'REQ_RETRY_01');
    });
  });

  describe('8. Unsupported Actions & Upstream Failures', () => {
    it('8-1. Rejects unsupported action with 400 ACTION_NOT_SUPPORTED', async () => {
      const handler = createBatchRelayHandler({ getEnv: () => mockEnv });
      const req = createMockReq({
        method: 'POST',
        body: { action: 'unsupported_dangerous_action' }
      });
      const res = createMockRes();

      await handler(req, res);
      assert.equal(res.statusCode, 400);
      assert.equal(res.body.error_code, 'ACTION_NOT_SUPPORTED');
    });

    it('8-2. Handles upstream GAS network error with 502 GAS_UPSTREAM_ERROR', async () => {
      const handler = createBatchRelayHandler({
        getEnv: () => mockEnv,
        fetchFn: async () => {
          throw new Error('Connection refused');
        }
      });

      const req = createMockReq({
        method: 'GET',
        query: { action: 'get_ai_product_draft_batch', batch_id: 'BAT_01' }
      });
      const res = createMockRes();

      await handler(req, res);
      assert.equal(res.statusCode, 502);
      assert.equal(res.body.error_code, 'GAS_UPSTREAM_ERROR');
    });

    it('8-3. Handles upstream GAS timeout with 504 GAS_TIMEOUT', async () => {
      const handler = createBatchRelayHandler({
        getEnv: () => mockEnv,
        fetchFn: async () => {
          const err = new Error('Timeout');
          err.name = 'TimeoutError';
          throw err;
        }
      });

      const req = createMockReq({
        method: 'GET',
        query: { action: 'get_ai_product_draft_batch', batch_id: 'BAT_01' }
      });
      const res = createMockRes();

      await handler(req, res);
      assert.equal(res.statusCode, 504);
      assert.equal(res.body.error_code, 'GAS_TIMEOUT');
    });

    it('8-4. Handles upstream GAS returning non-JSON HTML error with 502 GAS_INVALID_RESPONSE', async () => {
      const handler = createBatchRelayHandler({
        getEnv: () => mockEnv,
        fetchFn: async () => ({
          status: 500,
          text: async () => '<html><body>Internal Server Error</body></html>'
        })
      });

      const req = createMockReq({
        method: 'GET',
        query: { action: 'get_ai_product_draft_batch', batch_id: 'BAT_01' }
      });
      const res = createMockRes();

      await handler(req, res);
      assert.equal(res.statusCode, 502);
      assert.equal(res.body.error_code, 'GAS_INVALID_RESPONSE');
    });
  });
});
