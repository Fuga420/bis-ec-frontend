# gas-ai-batch-relay

Readdy（BIS管理画面フロントエンド）と Google Apps Script（GAS）間の「一括AI出品ドラフト生成」専用中継（Relay）サービスです。

ブラウザ側に管理者秘密鍵（`ADMIN_API_KEY`）や接続先GAS URLを露出させることなく、CORS制御およびJWT認証を行った上で、サーバー側で安全に認証情報を付加してGAS上流エンドポイントへリレーします。

---

## 1. アーキテクチャと処理フロー

```text
Readdy (フロントエンド UI)
  │
  │  POST / GET (Bearer JWT / CORS 制御)
  │  ※ mode や admin_key はリクエストに含めない
  ▼
gas-ai-batch-relay (Cloud Run functions / BFF)
  │
  ├─ 1. CORS オリジン検証 (ALLOWED_ORIGINS 照合)
  ├─ 2. OPTIONS プリフライト即時応答 (204 No Content)
  ├─ 3. JWT 認証検証 (JWT_SECRET 設定時、HS256 署名・有効期限検証)
  ├─ 4. 対象3アクションの選別・ペイロード検証
  │     - create_ai_product_draft_batch (POST)
  │     - get_ai_product_draft_batch (GET)
  │     - retry_ai_product_draft_batch (POST)
  ├─ 5. サーバー側環境変数より mode: "admin", admin_key: GAS_ADMIN_SECRET を安全に注入
  │     (クライアントからの改ざん値は上書き破棄)
  ▼
Google Apps Script (GAS Web App)
  │  URL: process.env.GAS_WEBHOOK_URL
  ▼
gas-ai-batch-relay
  │  上流レスポンスの JSON 検証、タイムアウト (30秒)・エラーハンドリング
  ▼
Readdy (進捗・結果レスポンス返却)
```

---

## 2. 対象エンドポイント (厳格に3アクションのみ)

| アクション | リレー側メソッド | GAS側メソッド | 役割 |
|---|---|---|---|
| `create_ai_product_draft_batch` | `POST` | `POST` | バッチ一括受付（最大20件、即時 `batch_id` 発行） |
| `get_ai_product_draft_batch` | `GET` (または `POST`) | `GET` | バッチ全体進捗と商品別状態の取得 |
| `retry_ai_product_draft_batch` | `POST` | `POST` | 失敗商品のみの再試行受付 |

※ 上記以外の未定義アクションは `400 Bad Request` (`ACTION_NOT_SUPPORTED`) で遮断されます。

---

## 3. 環境変数一覧

| 環境変数名 | 必須 | デフォルト値 | 説明 |
|---|---|---|---|
| `GAS_WEBHOOK_URL` | **◯** | - | 接続先 GAS Web App の `/exec` URL |
| `GAS_ADMIN_SECRET` | **◯** | - | GAS 側の `ADMIN_API_KEY` と一致させる秘密キー（Secret Manager 管理推奨） |
| `ALLOWED_ORIGINS` | 任意 | `*` | CORS 許可オリジン（カンマ区切り、例: `https://readdy.ai,https://app.currykicks.com`） |
| `JWT_SECRET` | 任意 | (空) | Readdy クライアント JWT 検証用シークレット（HS256） |
| `JWT_REQUIRED` | 任意 | `false` | `true` の場合、Authorization Bearer ヘッダーのないリクエストを 401 で遮断 |
| `GAS_REQUEST_TIMEOUT_MS` | 任意 | `30000` | GAS 上流通信タイムアウト時間（ミリ秒） |

---

## 4. Readdy からのリクエスト仕様

### 4.1 一括生成受付 (`create_ai_product_draft_batch`)
- **Method**: `POST`
- **Headers**:
  - `Content-Type: application/json`
  - `Authorization: Bearer <JWT_TOKEN>` (JWT検証有効時)
- **Body**:
  ```json
  {
    "action": "create_ai_product_draft_batch",
    "request_id": "REQ_20261005_BATCH_001",
    "product_ids": [
      "TMP-000088",
      "TMP-000090",
      "TMP-000027"
    ],
    "force_regenerate": false,
    "model_name": "gemini-3.5-flash-lite"
  }
  ```
- **Response (200 OK)**:
  ```json
  {
    "success": true,
    "batch_id": "BAT_20261005_123456_abc",
    "request_id": "REQ_20261005_BATCH_001",
    "status": "queued",
    "total_count": 3,
    "is_reused": false,
    "created_at": "2026-10-05T10:00:00.000Z"
  }
  ```

### 4.2 バッチ進捗・結果取得 (`get_ai_product_draft_batch`)
- **Method**: `GET`
- **Path**: `/?action=get_ai_product_draft_batch&batch_id=BAT_20261005_123456_abc`
- **Headers**:
  - `Authorization: Bearer <JWT_TOKEN>` (JWT検証有効時)
- **Response (200 OK)**:
  ```json
  {
    "success": true,
    "batch_id": "BAT_20261005_123456_abc",
    "status": "processing",
    "total_count": 3,
    "completed_count": 1,
    "failed_count": 0,
    "processing_count": 1,
    "items": [
      {
        "product_id": "TMP-000088",
        "status": "completed",
        "draft_id": "DRFT_TMP-000088_1728122490000",
        "draft_version": 1,
        "model_name": "gemini-3.5-flash-lite",
        "error_code": null,
        "error_message": null,
        "retry_count": 0
      },
      {
        "product_id": "TMP-000090",
        "status": "processing",
        "draft_id": null,
        "draft_version": null,
        "model_name": null,
        "error_code": null,
        "error_message": null,
        "retry_count": 0
      },
      {
        "product_id": "TMP-000027",
        "status": "pending",
        "draft_id": null,
        "draft_version": null,
        "model_name": null,
        "error_code": null,
        "error_message": null,
        "retry_count": 0
      }
    ]
  }
  ```

### 4.3 失敗分再試行 (`retry_ai_product_draft_batch`)
- **Method**: `POST`
- **Body**:
  ```json
  {
    "action": "retry_ai_product_draft_batch",
    "batch_id": "BAT_20261005_123456_abc",
    "request_id": "REQ_RETRY_20261005_001"
  }
  ```

---

## 5. デプロイ手順 (Google Cloud Run functions)

### 5.1 gcloud CLI によるデプロイ
```bash
gcloud functions deploy gas-ai-batch-relay \
  --gen2 \
  --runtime=nodejs22 \
  --region=asia-northeast1 \
  --source=. \
  --entry-point=gasAiBatchRelay \
  --trigger-http \
  --allow-unauthenticated \
  --set-env-vars="GAS_WEBHOOK_URL=https://script.google.com/macros/s/AKfycbyxee-2phIQl2KPBgx0h0bHBaaQDybUxbODI06ZC7aHNJg4jHMoKqFBSlBEQA2CHKfX/exec,ALLOWED_ORIGINS=https://readdy.ai" \
  --set-secrets="GAS_ADMIN_SECRET=GAS_ADMIN_SECRET:latest"
```

### 5.2 ローカル開発・テスト
```bash
# 依存関係インストール
npm install

# ローカル単体テスト実行 (全27件 PASS)
npm test

# ローカルエミュレータ起動
npm start
```
